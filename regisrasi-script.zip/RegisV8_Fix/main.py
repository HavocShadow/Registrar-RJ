#!/usr/bin/env python3
"""Compatibility entry point for the RegisV8 application."""

import asyncio

from app.main import main


if __name__ == "__main__":
    asyncio.run(main())
