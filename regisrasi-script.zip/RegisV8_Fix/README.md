# RegisV8

## Struktur folder

```text
RegisV8_Fix/
├── app/                  # Aplikasi utama dan modul inti
├── archive/              # Arsip kode
├── data/
│   ├── accounts/         # Input akun dan data terkait
│   ├── domains/          # Data serta hasil domain
│   └── links/            # Daftar URL input
├── debug/                # Dump HTML untuk debugging
├── output_regis/         # Hasil registrasi
├── scripts/              # Utilitas mandiri
├── yukcari/              # Utilitas dan data integrasi Yukcari
├── .env                  # Konfigurasi lokal
├── config.json           # Konfigurasi aplikasi
└── main.py               # Entry point kompatibilitas
```

File konfigurasi lokal dan kredensial tetap di root agar integrasi yang sudah
ada tidak kehilangan path. Log hasil dan dump debug juga tetap di lokasi lama.

## Contoh pemakaian

Jalankan dari folder `RegisV8_Fix`:

```bash
python3 main.py --links data/links/link.txt --accounts data/accounts/accounts.txt
python3 main.py --dashboard
python3 scripts/format_regis.py --help
python3 scripts/fetch_link.py
python3 yukcari/resolve_yukcari.py --help
```

## Pengelola TXT lokal

Untuk melihat, mencari, mengedit, mendeduplikasi URL, dan memvalidasi format
file TXT Yukcari tanpa menghubungi situs lain:

```bash
python3 yukcari/txt_manager.py
```

Buka `http://127.0.0.1:8765/` di browser. Server hanya bind ke localhost,
hanya membuka file TXT yang diizinkan di folder `yukcari/`, dan menyimpan cache
file berdasarkan perubahan di disk. Validasi format URL sepenuhnya offline.
Tekan `Ctrl+C` di terminal untuk menghentikan server.
