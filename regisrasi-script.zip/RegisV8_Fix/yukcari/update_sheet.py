import os
import queue
import string
import sys
import threading
import time
from pathlib import Path

import gspread
from google.oauth2.service_account import Credentials

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))
from scripts.failed_account_logs import extract_error_record


def get_log_source(filepath):
    """Map log filenames to the program users recognize."""
    source_names = {
        "888.log": "888.py",
        "mr2.log": "mr2.py",
        "auto_wd.log": "auto_wd.py",
        "sso-automation.log": "sso-automation",
    }
    filename = Path(filepath).name
    for log_filename, source in source_names.items():
        if filename == log_filename or filename.startswith(f"{log_filename}."):
            return source
    return filename


class SpreadsheetManager:
    def __init__(self, credentials_filepath, spreadsheet_id):
        self.credentials_filepath = credentials_filepath
        self.spreadsheet_id = spreadsheet_id
        self.client = None
        self.doc = None
        # A UserID can occur in multiple rows or worksheets.
        self.userid_cache = {}

    def authenticate(self):
        print("Autentikasi dengan Google Sheets API...")
        try:
            creds = Credentials.from_service_account_file(
                self.credentials_filepath,
                scopes=["https://www.googleapis.com/auth/spreadsheets"],
            )
            self.client = gspread.authorize(creds)
            self.doc = self.client.open_by_key(self.spreadsheet_id)
            print("Autentikasi berhasil!")
            return True
        except Exception as e:
            print(f"[ERROR] Gagal autentikasi Google Sheets: {e}")
            return False

    def get_column_data(self, sheet_name, col_index):
        worksheet = self.doc.worksheet(sheet_name)
        return worksheet.col_values(col_index)

    def cache_userids(self, sheet_name, rows, uid_col, first_data_row=2):
        """Cache every non-empty UserID at its actual row without a fixed limit."""
        for row_number, row_values in enumerate(rows, start=1):
            if row_number < first_data_row or len(row_values) < uid_col:
                continue
            userid = row_values[uid_col - 1].strip()
            if userid:
                self.userid_cache.setdefault(userid, []).append(
                    {"sheet": sheet_name, "row": row_number}
                )

    def highlight_specific_users(self, updates_by_sheet, uid_col):
        """Apply status colors: pending cyan, failed red, verification white."""
        red_format = {
            "backgroundColor": {"red": 1.0, "green": 0.0, "blue": 0.0},
            "textFormat": {"bold": True},
        }
        status_formats = {
            "PENDING": {
                "backgroundColor": {"red": 0.0, "green": 1.0, "blue": 1.0},
                "textFormat": {"bold": True},
            },
            "FAILED": red_format,
            "ERROR": red_format,
            "VERIFICATION FAILED": {
                "backgroundColor": {"red": 1.0, "green": 1.0, "blue": 1.0},
                "textFormat": {"bold": False},
            },
        }
        col_letter = string.ascii_uppercase[uid_col - 1]

        for sheet_name, rows_by_status in updates_by_sheet.items():
            try:
                worksheet = self.doc.worksheet(sheet_name)
                formats = []
                for row, status in rows_by_status.items():
                    cell_format = status_formats.get(status, status_formats["FAILED"])
                    formats.append({"range": f"{col_letter}{row}", "format": cell_format})
                if formats:
                    worksheet.batch_format(formats)
                    print(
                        f"[REALTIME HIGHLIGHT] {len(formats)} UserID diperbarui "
                        f"sesuai status pada sheet '{sheet_name}'."
                    )
                time.sleep(2)  # Anti limit 429 antar sheet
            except Exception as e:
                print(f"[ERROR HIGHLIGHT] Gagal mewarnai {sheet_name}: {e}")


class SyncApp:
    def __init__(self, config):
        self.config = config
        self.spreadsheet = SpreadsheetManager(
            config["credentials_filepath"], config["spreadsheet_id"]
        )
        self.error_queue = queue.Queue()

    def tail_log_file(self, filepath):
        """Tail a log, waiting for file creation and reopening it after rotation."""
        print(f"[WATCHER] Memulai pemantauan realtime pada: {filepath}")
        log_path = Path(filepath)
        skip_existing_content = log_path.exists()
        log_file = None
        file_identity = None
        while True:
            try:
                if not log_path.exists():
                    time.sleep(1)
                    continue

                if log_file is None or log_path.stat().st_ino != file_identity:
                    if log_file is not None:
                        log_file.close()
                    log_file = log_path.open("r", encoding="utf-8", errors="replace")
                    file_identity = os.fstat(log_file.fileno()).st_ino
                    if skip_existing_content:
                        log_file.seek(0, os.SEEK_END)
                        skip_existing_content = False
                    else:
                        log_file.seek(0)

                line = log_file.readline()
                if not line:
                    time.sleep(0.5)
                    continue

                record = extract_error_record(line, get_log_source(filepath))
                if record:
                    self.error_queue.put(record)
            except OSError as exc:
                print(f"[WATCHER ERROR] Gagal membaca {filepath}: {type(exc).__name__}")
                if log_file is not None:
                    log_file.close()
                    log_file = None
                time.sleep(1)

    def run(self):
        print("=== MENGHUBUNGKAN KE GOOGLE SHEETS ===")

        if not self.spreadsheet.authenticate():
            raise SystemExit(1)

        all_sheets = self.spreadsheet.doc.worksheets()
        uid_col = self.config["userid_column_index"]

        # Index UserIDs only; existing log records are deliberately not replayed.
        self.spreadsheet.userid_cache.clear()
        for sheet in all_sheets:
            sheet_name = sheet.title
            print(f"\nMemetakan UserID: {sheet_name}")
            try:
                rows = sheet.get_all_values()
                self.spreadsheet.cache_userids(
                    sheet_name,
                    rows,
                    uid_col,
                    first_data_row=self.config.get("first_userid_row", 2),
                )
            except Exception as e:
                print(f"[ERROR INIT] {sheet_name}: {e}")

        print(
            f"\n[USERID READY] Berhasil memetakan {len(self.spreadsheet.userid_cache)} UserID unik dari Spreadsheet."
        )
        print("\n=== MODE REALTIME: ERROR BARU SAJA ===")

        # Menjalankan mata-mata (thread) untuk setiap file log
        for filepath in self.config["error_log_filepaths"]:
            thread = threading.Thread(
                target=self.tail_log_file, args=(filepath,), daemon=True
            )
            thread.start()

        # Main Loop: apply each newly observed status; later statuses replace prior colors.
        while True:
            try:
                records_to_report = []

                # Kosongkan antrean yang terkumpul sejauh ini
                while not self.error_queue.empty():
                    records_to_report.append(self.error_queue.get())

                if records_to_report:
                    print(
                        f"\n[ERROR LOG] Menerima {len(records_to_report)} record error:"
                    )
                    for record in records_to_report:
                        print(
                            f"  - Sumber: {record['source']} | Level: {record['level']} "
                            f"| Status: {record['status']} | UserID: {record['account_id']}\n"
                            f"    Detail: {record['message']}"
                        )

                    updates_by_sheet = {}
                    latest_status_by_user = {}
                    for record in records_to_report:
                        latest_status_by_user[record["account_id"]] = record["status"]

                    for uid, status in latest_status_by_user.items():
                        locations = self.spreadsheet.userid_cache.get(uid, [])
                        for loc in locations:
                            updates_by_sheet.setdefault(loc["sheet"], {})[loc["row"]] = status
                        if not locations:
                            print(f"[USERID NOT FOUND] {uid} tidak ditemukan di kolom E semua sheet.")

                    if updates_by_sheet:
                        print(f"\n[REALTIME] Memperbarui warna {len(latest_status_by_user)} UserID.")
                        self.spreadsheet.highlight_specific_users(
                            updates_by_sheet, uid_col
                        )

                # Jeda 10 detik sebelum mengecek antrean lagi (DEBOUNCE / Anti-Limit 429)
                time.sleep(10)

            except KeyboardInterrupt:
                print("\n[STOP] Mematikan Daemon...")
                break
            except Exception as e:
                print(f"[DAEMON ERROR] {e}")
                time.sleep(10)


if __name__ == "__main__":
    mr888_log_dir = Path(__file__).resolve().parent.parent / "MR888" / "logs"
    APP_CONFIG = {
        "error_log_filepaths": [
            str(mr888_log_dir / "888.log"),
            str(mr888_log_dir / "mr2.log"),
            str(mr888_log_dir / "auto_wd.log"),
            str(Path(__file__).resolve().parent.parent / "sso-automation" / "logs" / "sso-automation.log"),
        ],
        "credentials_filepath": str(PROJECT_ROOT / "credentials.json"),
        "spreadsheet_id": "1HqY7KJr7XNwESSpBvptxybYPsGZ9CheoB1_xtv1pghI",
        "userid_column_index": 5,  # Kolom E
        "first_userid_row": 2,
    }

    app = SyncApp(APP_CONFIG)
    app.run()
