#!/usr/bin/env python3
"""Serve a localhost-only, offline editor for the Yukcari text files."""

import argparse
import atexit
import errno
import json
import logging
import os
import stat
import subprocess
import sys
import tempfile
import threading
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

BASE_DIR = Path(__file__).resolve().parent
PAGE_PATH = BASE_DIR / "txt_manager.html"
TEXT_FILES = (
    "link_hidup_tapi_tidak_aktif.txt",
    "link_mati.txt",
    "url_bonus_active_with_wd10k.txt",
    "url_live_with_login.txt",
    "url_live_with_min_withdraw_10k.txt",
    "yukcari_resolved.txt",
    "yukcari_resolved_mapping.txt",
)
MAX_FILE_BYTES = 1_000_000
MAX_DOMAINS_CACHE_BYTES = 10_000_000
DOMAINS_CACHE_PATH = BASE_DIR / "yukcari_domains_local.json"
UPDATE_LINKS_SCRIPT = BASE_DIR / "update_links.py"
UPDATE_LINKS_INPUT = BASE_DIR / "url_live_with_min_withdraw_10k.txt"
MAX_COMMAND_OUTPUT = 30_000
UPDATE_LINKS_CREDENTIALS = BASE_DIR.parent / "credentials.json"
UPDATE_SHEET_SCRIPT = BASE_DIR / "update_sheet.py"
UPDATE_SHEET_CREDENTIALS = BASE_DIR.parent / "credentials.json"
RESOLVE_YUKCARI_SCRIPT = BASE_DIR / "resolve_yukcari.py"
RESOLVE_YUKCARI_SOURCE = "https://yukcari.net/domains.json"
RESOLVE_YUKCARI_CREDENTIALS_DEFAULT = BASE_DIR.parent / "credentials.txt"

logging.basicConfig(level=logging.INFO, format="[%(levelname)s] %(message)s")
LOGGER = logging.getLogger("txt_manager")


class ManagedScript:
    """Manage one fixed local watcher process and retain its recent output."""

    def __init__(self) -> None:
        self._process: subprocess.Popen[str] | None = None
        self._output: deque[str] = deque(maxlen=400)
        self._lock = threading.RLock()
        self._column: str | None = None

    def _read_output(self, process: subprocess.Popen[str]) -> None:
        if process.stdout is None:
            return
        try:
            for line in process.stdout:
                with self._lock:
                    self._output.append(line.rstrip("\n")[:2_000])
        finally:
            process.stdout.close()

    def _start(self, command: list[str]) -> dict[str, object]:
        with self._lock:
            if self._process is not None and self._process.poll() is None:
                return {
                    "running": True,
                    "pid": self._process.pid,
                    "output": self.output(),
                }

            self._output.clear()
            self._process = subprocess.Popen(
                command,
                cwd=BASE_DIR,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
            )
            process = self._process
            threading.Thread(
                target=self._read_output,
                args=(process,),
                name="managed-script-output",
                daemon=True,
            ).start()
            return {"running": True, "pid": process.pid, "output": self.output()}

    # ------------------------------------------------------------------
    # UPDATE SHEET
    # ------------------------------------------------------------------

    def start(self) -> dict[str, object]:
        if not UPDATE_SHEET_SCRIPT.is_file() or UPDATE_SHEET_SCRIPT.is_symlink():
            raise FileNotFoundError("Script update_sheet.py tidak tersedia")
        if (
            not UPDATE_SHEET_CREDENTIALS.is_file()
            or UPDATE_SHEET_CREDENTIALS.is_symlink()
        ):
            raise FileNotFoundError(
                "credentials.json tidak ditemukan di folder RegisV8_Fix"
            )
        return self._start([sys.executable, "-u", str(UPDATE_SHEET_SCRIPT)])

    # ------------------------------------------------------------------
    # UPDATE LINKS
    # ------------------------------------------------------------------

    def start_update_links(self, url_col: int) -> dict[str, object]:
        if not UPDATE_LINKS_SCRIPT.is_file() or UPDATE_LINKS_SCRIPT.is_symlink():
            raise FileNotFoundError("Script update_links.py tidak tersedia")
        if not UPDATE_LINKS_INPUT.is_file() or UPDATE_LINKS_INPUT.is_symlink():
            raise FileNotFoundError(
                f"File sumber tidak tersedia: {UPDATE_LINKS_INPUT.name}"
            )
        if (
            not UPDATE_LINKS_CREDENTIALS.is_file()
            or UPDATE_LINKS_CREDENTIALS.is_symlink()
        ):
            raise FileNotFoundError(
                "credentials.json tidak ditemukan di folder RegisV8_Fix"
            )
        self._column = "E" if url_col == 5 else "F"
        return self._start(
            [
                sys.executable,
                "-u",
                str(UPDATE_LINKS_SCRIPT),
                "--input",
                str(UPDATE_LINKS_INPUT),
                "--url-col",
                str(url_col),
                "--once",
            ]
        )

    # ------------------------------------------------------------------
    # RESOLVE_YUKCARI — helpers
    # ------------------------------------------------------------------

    def _check_resolve_script(self) -> None:
        if not RESOLVE_YUKCARI_SCRIPT.is_file() or RESOLVE_YUKCARI_SCRIPT.is_symlink():
            raise FileNotFoundError("Script resolve_yukcari.py tidak tersedia")

    def _check_credentials_file(self, creds_arg: str | None) -> None:
        if creds_arg is None:
            return
        creds_path = Path(creds_arg)
        if not creds_path.is_absolute():
            creds_path = (BASE_DIR / creds_path).resolve()
        if not creds_path.is_file() or creds_path.is_symlink():
            raise FileNotFoundError(f"File credentials tidak ditemukan: {creds_path}")

    def _resolve_common_args(self) -> list[str]:
        return [
            sys.executable,
            "-u",
            str(RESOLVE_YUKCARI_SCRIPT),
            "--url",
            RESOLVE_YUKCARI_SOURCE,
            "--local",
            str(DOMAINS_CACHE_PATH),
        ]

    # ------------------------------------------------------------------
    # RESOLVE_YUKCARI — modes
    # ------------------------------------------------------------------

    def start_resolve_download(self) -> dict[str, object]:
        """Download-only: unduh domains.json ke cache lokal, tanpa resolve."""
        self._check_resolve_script()
        cmd = self._resolve_common_args() + ["--download-only"]
        return self._start(cmd)

    def start_resolve_check_login(self) -> dict[str, object]:
        """resolve_yukcari.py --check-login."""
        self._check_resolve_script()
        creds = RESOLVE_YUKCARI_CREDENTIALS_DEFAULT
        if not creds.is_file() or creds.is_symlink():
            raise FileNotFoundError(
                f"File credentials tidak ditemukan: {creds} "
                f"(dibutuhkan untuk --check-login)"
            )
        cmd = self._resolve_common_args() + [
            "--check-login",
            "--credentials-file",
            str(creds),
        ]
        return self._start(cmd)

    def start_resolve_check_offers(self) -> dict[str, object]:
        """resolve_yukcari.py --check-offers."""
        self._check_resolve_script()
        creds = RESOLVE_YUKCARI_CREDENTIALS_DEFAULT
        if not creds.is_file() or creds.is_symlink():
            raise FileNotFoundError(
                f"File credentials tidak ditemukan: {creds} "
                f"(dibutuhkan untuk --check-offers)"
            )
        cmd = self._resolve_common_args() + [
            "--check-offers",
            "--credentials-file",
            str(creds),
        ]
        return self._start(cmd)

    def start_resolve_full(self, options: dict[str, object]) -> dict[str, object]:
        """
        Jalankan resolve_yukcari.py secara penuh dengan opsi dari UI.

        options (semua opsional):
          url, local, no_download, processes, workers, interval, output,
          check_offers, check_login, login_workers, credentials_file
        """
        self._check_resolve_script()

        def _get_bool(key: str) -> bool:
            v = options.get(key, False)
            if not isinstance(v, bool):
                raise ValueError(f"{key} harus boolean")
            return v

        def _get_int(key: str, default: int | None, lo: int, hi: int) -> int | None:
            v = options.get(key)
            if v is None:
                return default
            if type(v) is not int:
                raise ValueError(f"{key} harus integer")
            if not (lo <= v <= hi):
                raise ValueError(f"{key} harus di rentang {lo}..{hi}")
            return v

        def _get_str(key: str, default: str | None = None) -> str | None:
            v = options.get(key, default)
            if v is None:
                return None
            if not isinstance(v, str) or not v.strip():
                raise ValueError(f"{key} harus string non-kosong")
            return v.strip()

        no_download = _get_bool("no_download")
        check_offers = _get_bool("check_offers")
        check_login = _get_bool("check_login")

        processes = _get_int("processes", 4, 1, 64)
        workers = _get_int("workers", 8, 1, 256)
        interval = _get_int("interval", 3600, 0, 7 * 24 * 3600)
        login_workers = _get_int("login_workers", 10, 1, 256)

        url = _get_str("url", RESOLVE_YUKCARI_SOURCE)
        local = _get_str("local", str(DOMAINS_CACHE_PATH))
        output = _get_str("output", None)
        credentials_file = _get_str("credentials_file", None)

        if (check_offers or check_login) and credentials_file:
            self._check_credentials_file(credentials_file)

        cmd: list[str] = [sys.executable, "-u", str(RESOLVE_YUKCARI_SCRIPT)]

        if no_download:
            cmd.append("--no-download")
        if processes is not None:
            cmd += ["--processes", str(processes)]
        if workers is not None:
            cmd += ["--workers", str(workers)]
        if interval is not None:
            cmd += ["--interval", str(interval)]
        if output:
            cmd += ["--output", output]
        if check_offers:
            cmd.append("--check-offers")
        if check_login:
            cmd.append("--check-login")
        if login_workers is not None:
            cmd += ["--login-workers", str(login_workers)]
        if credentials_file:
            cmd += ["--credentials-file", credentials_file]
        if url:
            cmd += ["--url", url]
        if local:
            cmd += ["--local", local]

        return self._start(cmd)

    # ------------------------------------------------------------------
    # Status / output / stop
    # ------------------------------------------------------------------

    def output(self) -> str:
        with self._lock:
            return "\n".join(self._output)[-MAX_COMMAND_OUTPUT:]

    def status(self) -> dict[str, object]:
        with self._lock:
            process = self._process
            return {
                "running": process is not None and process.poll() is None,
                "pid": process.pid if process is not None else None,
                "return_code": process.poll() if process is not None else None,
                "column": self._column,
                "output": self.output(),
            }

    def stop(self) -> dict[str, object]:
        with self._lock:
            process = self._process
        if process is None or process.poll() is not None:
            return self.status()

        process.terminate()
        try:
            process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait(timeout=3)
        return self.status()


UPDATE_SHEET = ManagedScript()
UPDATE_LINKS = ManagedScript()
RESOLVE_YUKCARI = ManagedScript()
atexit.register(UPDATE_SHEET.stop)
atexit.register(UPDATE_LINKS.stop)
atexit.register(RESOLVE_YUKCARI.stop)


class DomainsJsonCache:
    """Read the existing local domains JSON and cache it until the file changes."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._signature: tuple[int, int, int] | None = None
        self._payload: dict[str, object] | None = None

    def read(self) -> dict[str, object]:
        with self._lock:
            if DOMAINS_CACHE_PATH.is_symlink() or not DOMAINS_CACHE_PATH.is_file():
                raise FileNotFoundError(
                    "Cache lokal yukcari_domains_local.json tidak ditemukan"
                )

            file_stat = DOMAINS_CACHE_PATH.stat()
            signature = (file_stat.st_mtime_ns, file_stat.st_size, file_stat.st_ino)
            if self._payload is not None and self._signature == signature:
                return {**self._payload, "cache_hit": True}
            if file_stat.st_size > MAX_DOMAINS_CACHE_BYTES:
                raise ValueError(
                    f"File cache melebihi batas {MAX_DOMAINS_CACHE_BYTES} byte"
                )

            data = json.loads(DOMAINS_CACHE_PATH.read_text(encoding="utf-8-sig"))
            if not isinstance(data, dict) or not isinstance(data.get("brands"), list):
                raise ValueError(
                    "Format domains JSON tidak sesuai: field brands harus berupa daftar"
                )

            brands = []
            for item in data["brands"]:
                if not isinstance(item, dict):
                    continue
                brands.append(
                    {
                        "keyword": item.get("keyword", ""),
                        "name": item.get("name", ""),
                        "shortName": item.get("shortName", ""),
                        "url": item.get("url", ""),
                        "candidates": item.get("candidates", []),
                        "domains": item.get("domains", []),
                        "hasRedirect": item.get("hasRedirect", False),
                    }
                )

            payload: dict[str, object] = {
                "source": data.get("source", ""),
                "generatedAt": data.get("generatedAt", ""),
                "count": data.get("count", len(brands)),
                "brands": brands,
                "cache_hit": False,
            }
            self._signature = signature
            self._payload = payload
            return payload.copy()


DOMAINS_CACHE = DomainsJsonCache()


def _url_key(value: str) -> tuple[str, str, int | None, str, str, str] | None:
    """Return an offline comparison key for a syntactically valid HTTP URL."""
    candidate = value.strip()
    if not candidate or any(character.isspace() for character in candidate):
        return None

    try:
        parsed = urlsplit(candidate)
        if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
            return None
        if parsed.username is not None or parsed.password is not None:
            return None
        port = parsed.port
    except ValueError:
        return None

    return (
        parsed.scheme.lower(),
        parsed.hostname.lower(),
        port,
        parsed.path or "/",
        parsed.query,
        parsed.fragment,
    )


def analyze_text(content: str) -> dict[str, object]:
    valid_urls = 0
    invalid_lines: list[dict[str, object]] = []
    seen: set[tuple[str, str, int | None, str, str, str]] = set()
    duplicate_count = 0

    for line_number, raw_line in enumerate(content.splitlines(), start=1):
        value = raw_line.strip()
        if not value or value.startswith("#"):
            continue

        key = _url_key(value)
        if key is None:
            invalid_lines.append(
                {
                    "line": line_number,
                    "text": value,
                    "reason": "Bukan URL HTTP/HTTPS yang valid",
                }
            )
            continue

        valid_urls += 1
        if key in seen:
            duplicate_count += 1
        else:
            seen.add(key)

    return {
        "line_count": len(content.splitlines()),
        "valid_urls": valid_urls,
        "unique_urls": len(seen),
        "duplicate_urls": duplicate_count,
        "invalid_lines": invalid_lines[:100],
        "invalid_line_count": len(invalid_lines),
    }


def deduplicate_url_lines(content: str) -> tuple[str, int]:
    """Remove repeated valid URL lines, preserving all other text and line order."""
    seen: set[tuple[str, str, int | None, str, str, str]] = set()
    kept: list[str] = []
    removed = 0

    for raw_line in content.splitlines(keepends=True):
        value = raw_line.strip()
        key = _url_key(value)
        if key is not None:
            if key in seen:
                removed += 1
                continue
            seen.add(key)
        kept.append(raw_line)

    return "".join(kept), removed


class TextFileCache:
    """Cache approved text files until their on-disk stat changes."""

    def __init__(self) -> None:
        self._entries: dict[str, tuple[int, int, int, str]] = {}
        self._lock = threading.RLock()

    @staticmethod
    def path_for(name: str) -> Path:
        if name not in TEXT_FILES:
            raise ValueError("File tidak termasuk daftar file yang diizinkan")
        path = BASE_DIR / name
        if path.is_symlink() or not path.is_file():
            raise FileNotFoundError(f"File tidak tersedia: {name}")
        return path

    def read(self, name: str) -> tuple[str, bool]:
        path = self.path_for(name)
        with self._lock:
            file_stat = path.stat()
            signature = (file_stat.st_mtime_ns, file_stat.st_size, file_stat.st_ino)
            cached = self._entries.get(name)
            if cached and cached[:3] == signature:
                return cached[3], True

            if file_stat.st_size > MAX_FILE_BYTES:
                raise ValueError(f"File melebihi batas {MAX_FILE_BYTES} byte: {name}")
            content = path.read_text(encoding="utf-8-sig")
            self._entries[name] = (*signature, content)
            return content, False

    def write(self, name: str, content: str) -> None:
        path = self.path_for(name)
        encoded = content.encode("utf-8")
        if len(encoded) > MAX_FILE_BYTES:
            raise ValueError(f"Isi file melebihi batas {MAX_FILE_BYTES} byte")
        with self._lock:
            temp_path: Path | None = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="w",
                    encoding="utf-8",
                    newline="",
                    dir=BASE_DIR,
                    prefix=f".{name}.",
                    suffix=".tmp",
                    delete=False,
                ) as temp_file:
                    temp_file.write(content)
                    temp_path = Path(temp_file.name)
                os.chmod(temp_path, stat.S_IMODE(path.stat().st_mode))
                temp_path.replace(path)
                file_stat = path.stat()
                self._entries[name] = (
                    file_stat.st_mtime_ns,
                    file_stat.st_size,
                    file_stat.st_ino,
                    content,
                )
            finally:
                if temp_path is not None and temp_path.exists():
                    temp_path.unlink()


FILE_CACHE = TextFileCache()


class LocalhostHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class RequestHandler(BaseHTTPRequestHandler):
    server_version = "OfflineTxtManager/1.0"

    def _allowed_host(self) -> bool:
        expected_port = self.server.server_address[1]
        allowed = {f"127.0.0.1:{expected_port}", f"localhost:{expected_port}"}
        return self.headers.get("Host", "").lower() in allowed

    def _json_response(self, status: int, data: object) -> None:
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        try:
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(payload)
        except OSError as exc:
            if exc.errno not in {errno.EPIPE, errno.ECONNRESET, errno.ECONNABORTED}:
                raise
            LOGGER.debug("Klien menutup koneksi sebelum respons selesai dikirim")

    def _json_body(self) -> dict[str, object]:
        raw_length = self.headers.get("Content-Length", "")
        try:
            length = int(raw_length)
        except ValueError as exc:
            raise ValueError("Content-Length tidak valid") from exc
        if length < 0 or length > MAX_FILE_BYTES + 16_384:
            raise ValueError("Ukuran request melewati batas")
        data = json.loads(self.rfile.read(length))
        if not isinstance(data, dict):
            raise ValueError("Body JSON harus berupa object")
        return data

    def _check_request_origin(self) -> bool:
        if not self._allowed_host():
            self._json_response(403, {"error": "Host hanya boleh localhost"})
            return False
        if self.command == "POST":
            expected_origin = f"http://{self.headers.get('Host', '').lower()}"
            if self.headers.get("Origin") != expected_origin:
                self._json_response(403, {"error": "Origin request tidak diizinkan"})
                return False
        return True

    def do_GET(self) -> None:
        if not self._check_request_origin():
            return

        request = urlsplit(self.path)
        try:
            if request.path == "/":
                page = PAGE_PATH.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(page)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(page)
                return

            if request.path == "/api/files":
                files = []
                for name in TEXT_FILES:
                    content, cache_hit = FILE_CACHE.read(name)
                    files.append(
                        {
                            "name": name,
                            "line_count": len(content.splitlines()),
                            "bytes": len(content.encode("utf-8")),
                            "cache_hit": cache_hit,
                        }
                    )
                self._json_response(200, {"files": files})
                return

            if request.path == "/api/file":
                names = parse_qs(request.query).get("name", [])
                if len(names) != 1:
                    raise ValueError("Parameter name wajib diisi satu kali")
                content, cache_hit = FILE_CACHE.read(names[0])
                self._json_response(
                    200,
                    {
                        "name": names[0],
                        "content": content,
                        "cache_hit": cache_hit,
                    },
                )
                return
            if request.path == "/api/update-sheet/status":
                self._json_response(200, UPDATE_SHEET.status())
                return
            if request.path == "/api/update-links/status":
                self._json_response(200, UPDATE_LINKS.status())
                return
            if request.path == "/api/domains-cache":
                self._json_response(200, DOMAINS_CACHE.read())
                return
            if request.path == "/api/resolve-yukcari/status":
                self._json_response(200, RESOLVE_YUKCARI.status())
                return
        except (OSError, UnicodeError, ValueError) as exc:
            self._json_response(400, {"error": str(exc)})
            return

        self._json_response(404, {"error": "Endpoint tidak ditemukan"})

    def do_POST(self) -> None:
        if not self._check_request_origin():
            return

        request = urlsplit(self.path)
        try:
            body = self._json_body()
            if request.path == "/api/save":
                name = body.get("name")
                content = body.get("content")
                if not isinstance(name, str) or not isinstance(content, str):
                    raise ValueError("name dan content harus berupa teks")
                FILE_CACHE.write(name, content)
                self._json_response(200, {"saved": True, "name": name})
                return

            if request.path == "/api/analyze":
                content = body.get("content")
                if not isinstance(content, str):
                    raise ValueError("content harus berupa teks")
                if len(content.encode("utf-8")) > MAX_FILE_BYTES:
                    raise ValueError(f"Isi melewati batas {MAX_FILE_BYTES} byte")
                self._json_response(200, analyze_text(content))
                return

            if request.path == "/api/dedupe":
                content = body.get("content")
                if not isinstance(content, str):
                    raise ValueError("content harus berupa teks")
                if len(content.encode("utf-8")) > MAX_FILE_BYTES:
                    raise ValueError(f"Isi melewati batas {MAX_FILE_BYTES} byte")
                deduplicated, removed = deduplicate_url_lines(content)
                self._json_response(
                    200,
                    {"content": deduplicated, "removed": removed},
                )
                return

            if request.path == "/api/update-links/start":
                url_col = body.get("url_col")
                if type(url_col) is not int or url_col not in {5, 6}:
                    raise ValueError("Kolom URL hanya boleh E (5) atau F (6)")
                state = UPDATE_LINKS.start_update_links(url_col)
                state["column"] = "E" if url_col == 5 else "F"
                self._json_response(200, state)
                return

            if request.path == "/api/update-links/stop":
                self._json_response(200, UPDATE_LINKS.stop())
                return

            if request.path == "/api/update-sheet/start":
                state = UPDATE_SHEET.start()
                self._json_response(200, state)
                return

            if request.path == "/api/update-sheet/stop":
                state = UPDATE_SHEET.stop()
                self._json_response(200, state)
                return

            # ---------------- RESOLVE YUKCARI ----------------
            if request.path == "/api/resolve-yukcari/start":
                # Body kosong = perilaku lama (download-only)
                if not body:
                    self._json_response(200, RESOLVE_YUKCARI.start_resolve_download())
                    return
                if body.get("mode") == "download":
                    self._json_response(200, RESOLVE_YUKCARI.start_resolve_download())
                    return
                if body.get("mode") == "check-login":
                    self._json_response(
                        200, RESOLVE_YUKCARI.start_resolve_check_login()
                    )
                    return
                if body.get("mode") == "check-offers":
                    self._json_response(
                        200, RESOLVE_YUKCARI.start_resolve_check_offers()
                    )
                    return
                # Default: full mode dengan opsi dari body
                self._json_response(200, RESOLVE_YUKCARI.start_resolve_full(body))
                return

            if request.path == "/api/resolve-yukcari/start-download":
                self._json_response(200, RESOLVE_YUKCARI.start_resolve_download())
                return

            if request.path == "/api/resolve-yukcari/start-check-login":
                self._json_response(200, RESOLVE_YUKCARI.start_resolve_check_login())
                return

            if request.path == "/api/resolve-yukcari/start-check-offers":
                self._json_response(200, RESOLVE_YUKCARI.start_resolve_check_offers())
                return

            if request.path == "/api/resolve-yukcari/stop":
                self._json_response(200, RESOLVE_YUKCARI.stop())
                return

        except (OSError, UnicodeError, ValueError, json.JSONDecodeError) as exc:
            self._json_response(400, {"error": str(exc)})
            return

        self._json_response(404, {"error": "Endpoint tidak ditemukan"})

    def log_message(self, format_string: str, *args: object) -> None:
        LOGGER.info("%s - %s", self.address_string(), format_string % args)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Pengelola TXT offline khusus localhost"
    )
    parser.add_argument(
        "--port", type=int, default=8765, help="Port server (default: 8765)"
    )
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error("--port harus berada pada rentang 0..65535")

    server = LocalhostHTTPServer(("127.0.0.1", args.port), RequestHandler)
    address, port = server.server_address
    url = f"http://{address}:{port}/"
    print(f"Pengelola TXT lokal berjalan di {url}")
    print("Server hanya menerima koneksi localhost. Tekan Ctrl+C untuk berhenti.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer dihentikan.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
