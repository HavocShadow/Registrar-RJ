#!/usr/bin/env python3
"""Sinkronisasi URL live ke Google Sheets.

Menimpa kolom Link di setiap worksheet dengan URL dari file TXT,
dicocokkan berdasarkan brand.

Contoh:
    python update_links.py
    python update_links.py --input url_live.txt --interval 600
    python update_links.py --url-col 7
"""

import argparse
import re
import string
import time
from pathlib import Path
from urllib.parse import urlparse, urlunparse

import gspread
from google.oauth2.service_account import Credentials

SPREADSHEET_ID = "1V0olrqqSMhz705k2Iy-ubxeVpJU29rEXuwNBjc9Atw0"


def get_brand(url_string: str) -> str:
    if not url_string:
        return ""
    if not re.match(r"^https?://", url_string, re.IGNORECASE):
        url_string = "http://" + url_string

    netloc = urlparse(url_string).netloc.lower().replace("www.", "")
    parts = netloc.split(".")
    domain_name = parts[-2] if len(parts) > 2 else parts[0]
    match = re.match(r"^([a-z\-]+)", domain_name)
    return match.group(1) if match else domain_name


def build_txt_brand_map(txt_filepath: Path) -> dict[str, str]:
    brand_map: dict[str, str] = {}
    with txt_filepath.open("r", encoding="utf-8-sig") as file:
        for line_number, raw_line in enumerate(file, start=1):
            url = raw_line.strip()
            if not url or url.startswith("#"):
                continue

            if not re.match(r"^https?://", url, re.IGNORECASE):
                url = f"https://{url}"
            parsed_url = urlparse(url)
            if not parsed_url.hostname:
                raise ValueError(
                    f"URL tidak valid pada baris {line_number} di {txt_filepath}: "
                    f"{raw_line.strip()}"
                )

            brand = get_brand(url)
            if not brand:
                continue
            base_url = urlunparse(
                (parsed_url.scheme, parsed_url.netloc, "/", "", "", "")
            )
            brand_map[brand] = base_url

    if not brand_map:
        raise ValueError(f"Tidak ada URL valid di file TXT: {txt_filepath}")
    return brand_map


def update_sheet_links(doc, brand_map: dict[str, str], url_col: int) -> int:
    if not 1 <= url_col <= len(string.ascii_uppercase):
        raise ValueError(f"Indeks kolom URL tidak valid: {url_col}")
    col_letter = string.ascii_uppercase[url_col - 1]
    error_count = 0

    for worksheet in doc.worksheets():
        try:
            existing_urls = worksheet.col_values(url_col)
            new_values: list[list[str]] = []
            updated_count = 0

            for url in existing_urls:
                url_clean = url.strip() if url else ""
                if not url_clean:
                    new_values.append([""])
                    continue

                replacement = brand_map.get(get_brand(url_clean), url_clean)
                new_values.append([replacement])
                if replacement != url_clean:
                    updated_count += 1

            if updated_count:
                worksheet.update(
                    values=new_values,
                    range_name=f"{col_letter}1:{col_letter}{len(new_values)}",
                )
            print(
                f"[URL UPDATE] {worksheet.title}: {updated_count} link diperbarui "
                f"(kolom {col_letter})."
            )
        except Exception as exc:
            error_count += 1
            print(
                f"[URL UPDATE ERROR] {worksheet.title}: " f"{type(exc).__name__}: {exc}"
            )
    return error_count


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Sinkronisasi URL live ke Google Sheets")
    p.add_argument(
        "--input",
        type=Path,
        help="File TXT berisi URL live "
        "(default: url_live_with_min_withdraw_10k.txt)",
    )
    p.add_argument(
        "--interval",
        type=int,
        default=3600,
        help="Jeda antar siklus dalam detik (default: 3600)",
    )
    p.add_argument(
        "--url-col",
        type=int,
        default=6,
        help="Indeks kolom URL (1-based, default: 6 = F)",
    )
    p.add_argument(
        "--once",
        action="store_true",
        help="Jalankan satu siklus sinkronisasi lalu keluar",
    )
    args = p.parse_args()

    if args.interval <= 0:
        p.error("--interval harus lebih besar dari 0")
    if not 1 <= args.url_col <= len(string.ascii_uppercase):
        p.error(
            f"--url-col tidak valid: {args.url_col} "
            f"(harus 1..{len(string.ascii_uppercase)})"
        )
    return args


def main() -> int:
    args = parse_args()

    base_dir = Path(__file__).resolve().parent
    credentials_path = base_dir.parent / "credentials.json"
    txt_path = (
        args.input if args.input else base_dir / "url_live_with_min_withdraw_10k.txt"
    )
    if not txt_path.is_absolute():
        txt_path = Path.cwd() / txt_path

    col_letter = string.ascii_uppercase[args.url_col - 1]
    print(
        f"[WATCHER] Sinkronisasi aktif dari {txt_path}, "
        f"kolom {col_letter} (indeks {args.url_col}), "
        f"interval {args.interval} detik."
    )

    try:
        while True:
            failed = False
            try:
                brand_map = build_txt_brand_map(txt_path)
                credentials = Credentials.from_service_account_file(
                    credentials_path,
                    scopes=["https://www.googleapis.com/auth/spreadsheets"],
                )
                client = gspread.authorize(credentials)
                spreadsheet = client.open_by_key(SPREADSHEET_ID)
                worksheet_errors = update_sheet_links(
                    spreadsheet, brand_map, url_col=args.url_col
                )
                failed = worksheet_errors > 0
            except Exception as exc:
                print(f"[SYNC ERROR] {type(exc).__name__}: {exc}")
                failed = True

            if args.once:
                print("[SYNC] Siklus tunggal selesai.")
                return 1 if failed else 0

            print(f"[WATCHER] Siklus berikutnya dalam {args.interval} detik.")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\n[WATCHER] Ctrl+C diterima; sinkronisasi dihentikan dengan aman.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
