#!/usr/bin/env python3
"""
╔════════════════════════════════════════════════════════════════════════════╗
║         YUKCARI DOMAIN REDIRECT RESOLVER - MULTIPROCESS EDITION         ║
║                                                                          ║
║  1. Download domains.json dari yukcari.net                              ║
║  2. Extract semua URL dari field 'url' dan 'candidates'                  ║
║  3. Follow redirect (meta refresh + HTTP redirect)                       ║
║  4. Ambil endpoint akhir (final URL)                                     ║
║  5. Multiprocessing + ThreadPool concurrency                             ║
║  6. Output JSON + TXT                                                    ║
║                                                                          ║
║  Usage:                                                                  ║
║    python3 resolve_yukcari.py                                            ║
║    python3 resolve_yukcari.py --processes 4 --workers 8                 ║
║    python3 resolve_yukcari.py --no-download                              ║
║    python3 resolve_yukcari.py --check-offers                             ║
║    python3 resolve_yukcari.py --check-login                              ║
╚════════════════════════════════════════════════════════════════════════════╝
"""

import asyncio
import os
import re
import json
import time
import argparse
import subprocess
import tempfile
import urllib.parse
import requests
import threading
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from typing import Optional, Dict, Any, List, Tuple
from urllib.parse import urlparse, urljoin, parse_qs
from dataclasses import dataclass, field, asdict
from datetime import datetime

import urllib3
from playwright.async_api import (
    Error as PlaywrightError,
    TimeoutError as PlaywrightTimeoutError,
    async_playwright,
)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==================== COLOR ====================
class C:
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    RESET = '\033[0m'

_print_lock = threading.Lock()

def cprint(msg, color=C.WHITE, bold=False, end="\n"):
    with _print_lock:
        prefix = C.BOLD if bold else ""
        print(f"{prefix}{color}{msg}{C.RESET}", end=end, flush=True)

def log_info(msg):   cprint(f"[•] {msg}", C.CYAN)
def log_ok(msg):     cprint(f"[✓] {msg}", C.GREEN, bold=True)
def log_warn(msg):   cprint(f"[!] {msg}", C.YELLOW)
def log_err(msg):    cprint(f"[✗] {msg}", C.RED, bold=True)
def log_proc(msg):   cprint(f"[→] {msg}", C.MAGENTA)

# ==================== CONFIG ====================
BASE_DIR = Path(__file__).resolve().parent
YUKCARI_URL = "https://yukcari.net/domains.json"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36"
TIMEOUT = 15
MAX_REDIRECTS = 20
OUTPUT_JSON = str(BASE_DIR / "yukcari_domains_local.json")
OUTPUT_RESOLVED_JSON = str(BASE_DIR / "yukcari_resolved.json")
OUTPUT_RESOLVED_TXT = str(BASE_DIR / "yukcari_resolved.txt")
OUTPUT_MAPPING_TXT = str(BASE_DIR / "yukcari_resolved_mapping.txt")
LOGIN_CHECK_WORKERS = 10

# ==================== DATA MODEL ====================
@dataclass
class DomainResult:
    keyword: str = ""
    name: str = ""
    short_name: str = ""
    original_url: str = ""
    final_url: str = ""
    final_domain: str = ""
    redirect_type: str = ""
    redirect_chain: List[str] = field(default_factory=list)
    status: str = "unknown"
    error: str = ""
    http_status: int = 0
    elapsed: float = 0.0
    login_url: str = ""
    login_http_status: int = 0
    login_status: str = ""
    login_error: str = ""


def make_login_url(url: str) -> str:
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"URL situs tidak valid untuk pemeriksaan login: {url}")
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, "/login", "", ""))


async def check_login_page(browser, result: DomainResult) -> DomainResult:
    """Classify a resolved site by inspecting its rendered /login page."""
    if result.status != "success" or not result.final_url:
        result.login_status = "dead"
        result.login_error = result.error or f"resolver status: {result.status}"
        return result

    context = None
    try:
        result.login_url = make_login_url(result.final_url)
        context = await browser.new_context(
            ignore_https_errors=True,
            user_agent=USER_AGENT,
        )
        login_page = await context.new_page()
        response = await login_page.goto(
            result.login_url,
            wait_until="domcontentloaded",
            timeout=TIMEOUT * 1000,
        )
        result.login_http_status = response.status if response else 0

        if result.login_http_status >= 500:
            result.login_status = "dead"
            result.login_error = f"HTTP {result.login_http_status}"
        else:
            try:
                await login_page.wait_for_function(
                    """() => {
                        const form = document.querySelector('form.login__form');
                        if (!form) return false;
                        const root = form.closest('div.login');
                        if (!root) return false;
                        const title = root.querySelector('.login__title');
                        if (!title || !form) return false;
                        const normalizedTitle = (title.textContent || '')
                            .replace(/\\s+/g, ' ')
                            .trim()
                            .toUpperCase();
                        return normalizedTitle === 'LOGIN'
                            && !!form.querySelector(
                                'input[formcontrolname="account"][name="account"][type="text"]'
                            )
                            && !!form.querySelector(
                                'input[formcontrolname="password"][name="password"][type="password"]'
                            )
                            && !!form.querySelector(
                                'app-captcha-input, .captcha-input'
                            );
                    }""",
                    timeout=min(TIMEOUT * 1000, 10000),
                )
                result.login_status = "live_with_login"
            except PlaywrightTimeoutError:
                result.login_status = "live_inactive"
                result.login_error = (
                    f"HTTP {result.login_http_status}; marker form login tidak ditemukan "
                    "pada DOM setelah JavaScript dirender"
                )

            if result.login_http_status == 0:
                result.login_status = "dead"
                result.login_error = "Browser tidak menerima response HTTP dari endpoint /login"
    except PlaywrightTimeoutError as exc:
        result.login_status = "dead"
        result.login_error = f"Timeout membuka /login: {exc}"
    except PlaywrightError as exc:
        result.login_status = "dead"
        result.login_error = f"Playwright {type(exc).__name__}: {exc}"
    except ValueError as exc:
        result.login_status = "dead"
        result.login_error = str(exc)
    finally:
        if context:
            await context.close()
    return result


def check_login_pages(results: List[DomainResult], workers: int = LOGIN_CHECK_WORKERS):
    async def run_checks():
        total = len(results)
        semaphore = asyncio.Semaphore(workers)
        completed = 0
        progress_lock = asyncio.Lock()

        async with async_playwright() as playwright:
            try:
                browser = await playwright.chromium.launch(headless=True)
            except PlaywrightError as exc:
                raise RuntimeError(
                    "Gagal menjalankan Chromium Playwright untuk pemeriksaan /login. "
                    "Pastikan browser Playwright sudah di-install."
                ) from exc

            async def check_one(result):
                nonlocal completed
                async with semaphore:
                    checked = await check_login_page(browser, result)

                    async with progress_lock:
                        completed += 1
                        log_info(
                            f"[{completed}/{total}] {checked.login_status}: "
                            f"{checked.login_url or checked.original_url}"
                        )

            try:
                await asyncio.gather(*(check_one(result) for result in results))
            finally:
                await browser.close()

    total = len(results)
    log_info(
        f"Memeriksa endpoint /login dengan Playwright Chromium pada "
        f"{total} URL (maksimum {workers} halaman bersamaan)"
    )
    asyncio.run(run_checks())

    active = sum(result.login_status == "live_with_login" for result in results)
    inactive = sum(result.login_status == "live_inactive" for result in results)
    dead = sum(result.login_status == "dead" for result in results)
    log_info(f"Hasil /login: {active} login aktif, {inactive} hidup tanpa marker, {dead} mati/error")


def save_login_check_results(results: List[DomainResult], output_dir: Path):
    output_files = {
        "live_with_login": output_dir / "url_live_with_login.txt",
        "live_inactive": output_dir / "link_hidup_tapi_tidak_aktif.txt",
        "dead": output_dir / "link_mati.txt",
    }

    for status, output_file in output_files.items():
        urls = sorted({
            result.login_url or result.final_url or result.original_url
            for result in results
            if result.login_status == status
        })
        output_file.write_text("".join(f"{url}\n" for url in urls), encoding="utf-8")
        log_ok(f"Hasil pemeriksaan /login ({len(urls)} URL): {output_file}")

# ==================== DOWNLOAD ====================
def download_domains_json(url: str = YUKCARI_URL, output_file: str = OUTPUT_JSON) -> Optional[Dict]:
    log_info(f"Downloading domains.json from {url}")
    try:
        headers = {
            "User-Agent": USER_AGENT,
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
        }
        resp = requests.get(url, headers=headers, timeout=30, verify=False)
        if resp.status_code != 200:
            log_err(f"HTTP {resp.status_code} saat download")
            return None
        data = resp.json()
        if not isinstance(data, dict) or not isinstance(data.get("brands"), list):
            log_err("Format domains.json tidak valid: field 'brands' harus berupa array")
            return None

        output_path = Path(output_file)
        temp_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=output_path.parent,
                prefix=f".{output_path.name}.",
                suffix=".tmp",
                delete=False,
            ) as output:
                json.dump(data, output, indent=2, ensure_ascii=False)
                temp_path = Path(output.name)
            os.replace(temp_path, output_path)
        finally:
            if temp_path is not None and temp_path.exists():
                temp_path.unlink()
        log_ok(f"Downloaded & saved: {output_file}")
        log_info(f"  Total brands: {data.get('count', 0)}")
        log_info(f"  Generated: {data.get('generatedAt', 'N/A')}")
        return data
    except Exception as e:
        log_err(f"Gagal download: {e}")
        return None


def load_local_json(file_path: str = OUTPUT_JSON) -> Optional[Dict]:
    if not os.path.exists(file_path):
        log_err(f"File {file_path} tidak ada")
        return None
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        log_ok(f"Loaded local: {file_path}")
        return data
    except Exception as e:
        log_err(f"Gagal load {file_path}: {e}")
        return None


# ==================== EXTRACT URLS ====================
def extract_urls_from_json(data: Dict) -> List[Dict]:
    """Ambil semua URL dari brands, dari field 'url' dan 'candidates'. Return list of {keyword, name, short_name, url}."""
    entries = []
    seen = set()
    brands = data.get("brands", [])
    for brand in brands:
        keyword = brand.get("keyword", "")
        name = brand.get("name", "")
        short_name = brand.get("shortName", "")
        urls = []
        # primary url
        if brand.get("url"):
            urls.append(brand["url"])
        # candidates
        for c in brand.get("candidates", []):
            if c and c not in urls:
                urls.append(c)
        # domains (tanpa http)
        for d in brand.get("domains", []):
            if d:
                u = d if d.startswith(("http://", "https://")) else f"https://{d}"
                if u not in urls:
                    urls.append(u)
        # Normalisasi & dedup
        for u in urls:
            u = u.strip().rstrip("/")
            if not u:
                continue
            if not u.startswith(("http://", "https://")):
                u = "https://" + u
            key = u.lower()
            if key in seen:
                continue
            seen.add(key)
            entries.append({
                "keyword": keyword,
                "name": name,
                "short_name": short_name,
                "url": u,
            })
    return entries


# ==================== REDIRECT RESOLVER ====================
def extract_meta_refresh(html: str) -> Optional[str]:
    """Ekstrak URL dari meta refresh."""
    patterns = [
        r'<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^"\']*url=([^"\']+)["\'][^>]*>',
        r'<meta[^>]*content=["\'][^"\']*url=([^"\']+)["\'][^>]*http-equiv=["\']refresh["\'][^>]*>',
        r'<meta[^>]*http-equiv=["\']refresh["\'][^>]*content=["\'][^"\']*;url=([^"\']+)["\'][^>]*>',
        r'<meta[^>]*content=["\'][^"\']*;url=([^"\']+)["\'][^>]*http-equiv=["\']refresh["\'][^>]*>',
        r'<meta[^>]*content=["\'][^"\']*\d+;url=([^"\']+)["\'][^>]*>',
    ]
    for pattern in patterns:
        m = re.search(pattern, html, re.IGNORECASE | re.DOTALL)
        if m:
            u = m.group(1).strip().replace('"', '').replace("'", '').replace(' ', '')
            return u
    return None


def normalize_url(url: str) -> str:
    url = url.strip()
    if not url:
        return url
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url.rstrip("/")


def follow_redirect(url: str, max_redirects: int = MAX_REDIRECTS) -> DomainResult:
    """Follow HTTP redirect + meta refresh, ambil final URL."""
    result = DomainResult(original_url=url)
    start = time.time()

    current_url = normalize_url(url)
    result.final_url = current_url
    result.final_domain = urlparse(current_url).netloc

    try:
        session = requests.Session()
        session.headers.update({
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
            "Upgrade-Insecure-Requests": "1",
        })

        redirect_count = 0
        seen_urls = set()

        while redirect_count < max_redirects:
            if current_url in seen_urls:
                result.status = "loop_detected"
                break
            seen_urls.add(current_url)

            try:
                resp = session.get(current_url, timeout=TIMEOUT, verify=False, allow_redirects=False)
            except requests.exceptions.Timeout:
                result.status = "timeout"
                result.error = f"Timeout at {current_url}"
                result.elapsed = time.time() - start
                return result
            except requests.exceptions.ConnectionError as e:
                result.status = "connection_error"
                result.error = str(e)[:120]
                result.elapsed = time.time() - start
                return result
            except Exception as e:
                result.status = "error"
                result.error = str(e)[:120]
                result.elapsed = time.time() - start
                return result

            result.http_status = resp.status_code

            # 1. HTTP redirect
            if resp.status_code in (301, 302, 303, 307, 308):
                location = resp.headers.get("Location", "")
                if location:
                    location = urljoin(current_url, location)
                    result.redirect_chain.append(f"[HTTP {resp.status_code}] {current_url} → {location}")
                    current_url = location
                    result.redirect_type = "http"
                    redirect_count += 1
                    continue

            # 2. Meta refresh
            if resp.status_code == 200:
                html = resp.text
                meta_url = extract_meta_refresh(html)
                if meta_url:
                    meta_url = urljoin(current_url, meta_url)
                    result.redirect_chain.append(f"[META] {current_url} → {meta_url}")
                    current_url = meta_url
                    result.redirect_type = "meta_refresh"
                    redirect_count += 1
                    continue

            # 3. Selesai — tidak ada redirect
            break

        result.final_url = current_url
        result.final_domain = urlparse(current_url).netloc
        result.status = "success"
        if result.final_url != normalize_url(url):
            result.redirect_type = result.redirect_type or "unknown"

    except Exception as e:
        result.status = "error"
        result.error = str(e)[:150]

    result.elapsed = time.time() - start
    return result


# ==================== CONCURRENT (ThreadPool) ====================
def resolve_concurrent(entries: List[Dict], workers: int = 20) -> List[DomainResult]:
    """Resolve semua entries paralel menggunakan ThreadPoolExecutor."""
    results: List[DomainResult] = []
    total = len(entries)
    done = 0
    ok = 0
    fail = 0

    log_info(f"🚀 Resolving {total} URLs dengan {workers} worker (thread pool)")

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {
            executor.submit(follow_redirect, e["url"]): e
            for e in entries
        }
        for fut in as_completed(future_map):
            entry = future_map[fut]
            try:
                r = fut.result()
            except Exception as e:
                r = DomainResult(original_url=entry["url"], status="error", error=str(e))
            # Lengkapi metadata
            r.keyword = entry.get("keyword", "")
            r.name = entry.get("name", "")
            r.short_name = entry.get("short_name", "")
            results.append(r)

            done += 1
            if r.status == "success":
                ok += 1
                if r.final_domain:
                    log_ok(f"[{done}/{total}] ✓ {entry['url'][:60]} → {r.final_domain}")
                else:
                    log_ok(f"[{done}/{total}] ✓ {entry['url'][:60]} (no redirect)")
            else:
                fail += 1
                log_err(f"[{done}/{total}] ✗ {entry['url'][:60]} → {r.status}: {r.error[:60]}")

    log_info(f"✅ Selesai: {ok} sukses, {fail} gagal dari {total}")
    return results


# ==================== MULTIPROCESS ====================
def _worker_process(entries_chunk: List[Dict], workers_per_proc: int) -> List[DomainResult]:
    """Worker function untuk ProcessPoolExecutor."""
    return resolve_concurrent(entries_chunk, workers=workers_per_proc)


def resolve_multiprocess(entries: List[Dict], processes: int = 4,
                         workers_per_process: int = 8) -> List[DomainResult]:
    """Bagi entries jadi beberapa chunk, jalankan di beberapa proses."""
    if processes <= 1:
        return resolve_concurrent(entries, workers=workers_per_process)

    # Bagi rata round-robin
    chunks: List[List[Dict]] = [[] for _ in range(processes)]
    for i, e in enumerate(entries):
        chunks[i % processes].append(e)
    chunks = [c for c in chunks if c]

    log_info(f"🧠 Multiprocessing: {len(chunks)} proses × {workers_per_process} thread = "
             f"{len(chunks) * workers_per_process} concurrent tasks")

    results: List[DomainResult] = []
    with ProcessPoolExecutor(max_workers=len(chunks)) as executor:
        futures = []
        for idx, chunk in enumerate(chunks):
            futures.append(executor.submit(_worker_process, chunk, workers_per_process))

        for fut in as_completed(futures):
            try:
                chunk_results = fut.result()
                results.extend(chunk_results)
                ok = sum(1 for r in chunk_results if r.status == "success")
                log_info(f"  → 1 proses selesai: {ok}/{len(chunk_results)} sukses")
            except Exception as e:
                log_err(f"Proses gagal: {e}")

    return results


# ==================== OUTPUT ====================
def save_resolved_json(results: List[DomainResult], output_file: str):
    uniq_final = sorted(set(r.final_url for r in results if r.status == "success" and r.final_url))
    uniq_domain = sorted(set(r.final_domain for r in results if r.status == "success" and r.final_domain))

    data = {
        "generated_at": datetime.now().isoformat(),
        "total": len(results),
        "success": sum(1 for r in results if r.status == "success"),
        "failed": sum(1 for r in results if r.status != "success"),
        "unique_final_domains": uniq_domain,
        "results": [asdict(r) for r in results],
    }
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    log_ok(f"Resolved JSON: {output_file}")


def save_status_results(results: List[DomainResult], output_dir: Path):
    generated_at = datetime.now().isoformat()
    live_results = [r for r in results if r.status == "success"]
    dead_results = [r for r in results if r.status != "success"]

    for filename, selected_results in (
        ("live_urls.json", live_results),
        ("dead_urls.json", dead_results),
    ):
        output_file = output_dir / filename
        data = {
            "generated_at": generated_at,
            "total": len(selected_results),
            "results": [asdict(r) for r in selected_results],
        }
        with output_file.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        log_ok(f"Status JSON: {output_file}")


def save_resolved_txt(results: List[DomainResult], output_file: str):
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"# YUKCARI RESOLVED DOMAINS - {datetime.now().isoformat()}\n")
        f.write(f"# Total: {len(results)}\n")
        f.write("# ============================================================\n\n")

        # Unique final domains
        uniq_domains = sorted(set(r.final_domain for r in results if r.status == "success" and r.final_domain))
        f.write(f"[UNIQUE FINAL DOMAINS] ({len(uniq_domains)})\n")
        for d in uniq_domains:
            f.write(f"{d}\n")

        f.write("\n\n[FINAL URLS]\n")
        uniq_urls = sorted(set(r.final_url for r in results if r.status == "success" and r.final_url))
        for u in uniq_urls:
            f.write(f"{u}\n")

        f.write("\n\n[DETAILS]\n")
        for r in results:
            f.write(f"keyword    : {r.keyword}\n")
            f.write(f"name       : {r.name}\n")
            f.write(f"short_name : {r.short_name}\n")
            f.write(f"original   : {r.original_url}\n")
            if r.status == "success":
                f.write(f"final      : {r.final_url}\n")
                f.write(f"final_dom  : {r.final_domain}\n")
                f.write(f"redirect   : {r.redirect_type}\n")
                if r.redirect_chain:
                    f.write(f"chain      :\n")
                    for step in r.redirect_chain:
                        f.write(f"    {step}\n")
            else:
                f.write(f"status     : {r.status}\n")
                f.write(f"error      : {r.error}\n")
            f.write(f"http_code  : {r.http_status}\n")
            f.write(f"elapsed    : {r.elapsed:.2f}s\n")
            f.write("-" * 60 + "\n")
    log_ok(f"Resolved TXT: {output_file}")


def save_mapping_txt(results: List[DomainResult], output_file: str):
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"# YUKCARI DOMAIN MAPPING - {datetime.now().isoformat()}\n")
        f.write("# format: original_url → final_url\n")
        f.write("# ============================================================\n\n")
        for r in results:
            if r.status == "success" and r.final_url:
                if r.final_url != r.original_url:
                    f.write(f"{r.original_url} → {r.final_url}\n")
                else:
                    f.write(f"{r.original_url} → (no redirect)\n")
            else:
                f.write(f"{r.original_url} → [ERROR: {r.status}]\n")
    log_ok(f"Mapping TXT: {output_file}")


def check_bonus_and_withdraw(results: List[DomainResult], output_file: str,
                             credentials_file: Optional[str] = None):
    """Run the existing authenticated browser checker against resolved URLs."""
    urls = sorted(set(
        r.final_url for r in results
        if r.status == "success" and r.final_url
    ))
    output_path = Path(output_file).resolve()

    if not urls:
        output_path.write_text("", encoding="utf-8")
        log_warn("Tidak ada URL hasil resolve untuk dicek bonus/withdraw")
        return

    checker = BASE_DIR.parent.parent / "sso-automation" / "tools" / "check-bonus.js"
    if not checker.is_file():
        raise FileNotFoundError(f"Script pengecekan bonus tidak ditemukan: {checker}")

    credentials_path = (
        Path(credentials_file).resolve()
        if credentials_file
        else BASE_DIR.parent / "credentials.txt"
    )
    if not credentials_file and not credentials_path.is_file():
        credentials_path = None
        log_warn(
            "credentials.txt tidak ditemukan; checker hanya memakai kredensial "
            "domain dari konfigurasi sso-automation"
        )
    elif not credentials_file:
        log_info(f"Memakai file kredensial default: {credentials_path}")
    if credentials_path and not credentials_path.is_file():
        raise FileNotFoundError(f"File kredensial tidak ditemukan: {credentials_path}")

    with tempfile.TemporaryDirectory(prefix="yukcari-offer-check-") as temp_dir:
        urls_file = Path(temp_dir) / "resolved_urls.txt"
        urls_file.write_text("\n".join(urls) + "\n", encoding="utf-8")
        command = [
            "node",
            str(checker),
            "--file",
            str(urls_file),
            "--wd10k-output",
            str(output_path),
        ]
        if credentials_path:
            command.extend(["--credentials-file", str(credentials_path)])
        log_info(f"Memeriksa bonus Pragmatic Play 20K dan minimal withdraw Rp 10.000 pada {len(urls)} URL")
        completed = subprocess.run(command, cwd=checker.parent.parent, check=False)

    if completed.returncode not in (0, 1):
        raise RuntimeError(f"Pengecekan bonus/withdraw gagal dengan exit code {completed.returncode}")
    if completed.returncode == 1:
        log_warn("Sebagian URL tidak memiliki bonus atau mengalami error; lihat check-bonus-result.json")
    log_info(f"Daftar URL dengan bonus dan minimal withdraw Rp 10.000: {output_path}")


# ==================== MAIN ====================
def run_monitoring_cycle(args):
    data = None
    entries: List[Dict] = []
    results: List[DomainResult] = []
    start_time = time.time()

    if args.no_download:
        data = load_local_json(args.local)
    else:
        data = download_domains_json(args.url, args.local)

    if not data:
        log_err("Gagal mendapatkan domains.json; siklus berikutnya akan mencoba lagi")
        return

    entries = extract_urls_from_json(data)
    log_info(f"Total URL unik: {len(entries)}")
    if not entries:
        log_err("Tidak ada URL yang diekstrak; siklus berikutnya akan mencoba lagi")
        return

    if args.processes > 1:
        results = resolve_multiprocess(
            entries,
            processes=args.processes,
            workers_per_process=args.workers,
        )
    else:
        results = resolve_concurrent(entries, workers=args.workers)

    if args.check_login:
        check_login_pages(results, workers=args.login_workers)
        save_login_check_results(results, Path(__file__).resolve().parent)

    save_resolved_json(results, OUTPUT_RESOLVED_JSON)
    save_resolved_txt(results, OUTPUT_RESOLVED_TXT)
    save_mapping_txt(results, OUTPUT_MAPPING_TXT)
    save_status_results(results, Path(__file__).resolve().parent)
    if args.check_offers:
        output_path = BASE_DIR / "url_bonus_active_with_wd10k.txt"
        check_bonus_and_withdraw(results, str(output_path), args.credentials_file)

    elapsed = time.time() - start_time
    total = len(results)
    ok = sum(1 for r in results if r.status == "success")
    fail = total - ok

    print()
    print("═" * 70)
    cprint("  SUMMARY", C.BOLD + C.YELLOW)
    print("═" * 70)
    cprint(f"  Total URLs     : {total}", C.WHITE)
    cprint(f"  Success        : {ok}", C.GREEN, bold=True)
    cprint(f"  Failed         : {fail}", C.RED, bold=True)
    cprint(f"  Time           : {elapsed:.1f}s", C.CYAN)
    cprint(f"  Speed          : {total / max(elapsed, 0.001):.2f} URL/s", C.CYAN)
    print()

    uniq_domains = sorted(set(r.final_domain for r in results if r.status == "success" and r.final_domain))
    cprint(f"  UNIQUE FINAL DOMAINS ({len(uniq_domains)}):", C.BOLD + C.GREEN)
    for domain in uniq_domains[:20]:
        cprint(f"    • {domain}", C.GREEN)
    if len(uniq_domains) > 20:
        cprint(f"    ... dan {len(uniq_domains) - 20} lainnya", C.DIM)
    print()


def main():
    parser = argparse.ArgumentParser(
        description="Yukcari Domain Redirect Resolver",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--url", default=YUKCARI_URL, help="URL domains.json")
    parser.add_argument("--local", default=OUTPUT_JSON, help="Path file lokal")
    parser.add_argument(
        "--download-only",
        action="store_true",
        help="Unduh domains.json ke file lokal lalu keluar tanpa resolve URL atau monitoring",
    )
    parser.add_argument("--no-download", action="store_true", help="Skip download, pakai file lokal")
    parser.add_argument("--processes", type=int, default=4, help="Jumlah proses (default: 4)")
    parser.add_argument("--workers", type=int, default=8, help="Thread per proses (default: 8)")
    parser.add_argument(
        "--interval",
        type=int,
        default=3600,
        help="Jeda antar siklus dalam detik (default: 3600)",
    )
    parser.add_argument(
        "--output",
        "-o",
        default=str(BASE_DIR / "yukcari_resolved"),
        help="Prefix output file",
    )
    parser.add_argument(
        "--check-offers",
        action="store_true",
        help="Cek bonus Pragmatic Play 20K dan withdraw minimum Rp 10.000 memakai login API",
    )
    parser.add_argument(
        "--check-login",
        action="store_true",
        help="Periksa endpoint /login dan cocokkan struktur form login yang diharapkan",
    )
    parser.add_argument(
        "--login-workers",
        type=int,
        default=LOGIN_CHECK_WORKERS,
        help=f"Thread pemeriksaan /login (default: {LOGIN_CHECK_WORKERS})",
    )
    parser.add_argument(
        "--credentials-file",
        help="File satu baris username|password untuk login yang dipakai pada semua URL hasil resolve",
    )
    args = parser.parse_args()
    if args.interval <= 0:
        parser.error("--interval harus lebih besar dari 0")
    if args.login_workers <= 0:
        parser.error("--login-workers harus lebih besar dari 0")

    if args.download_only:
        if args.check_offers or args.check_login:
            parser.error("--download-only tidak dapat digabung dengan pemeriksaan login atau offers")
        data = download_domains_json(args.url, args.local)
        if not data:
            raise SystemExit(1)
        log_ok("Mode download-only selesai; tidak ada URL brand yang dibuka atau di-resolve.")
        return

    global OUTPUT_RESOLVED_JSON, OUTPUT_RESOLVED_TXT, OUTPUT_MAPPING_TXT
    OUTPUT_RESOLVED_JSON = f"{args.output}.json"
    OUTPUT_RESOLVED_TXT = f"{args.output}.txt"
    OUTPUT_MAPPING_TXT = f"{args.output}_mapping.txt"

    log_info(f"Pemantauan kontinu aktif; interval {args.interval} detik")
    try:
        while True:
            try:
                run_monitoring_cycle(args)
            except KeyboardInterrupt:
                raise
            except Exception as e:
                log_err(f"Siklus pemantauan gagal: {e}")

            log_info(f"Siklus berikutnya dimulai dalam {args.interval} detik")
            time.sleep(args.interval)
    except KeyboardInterrupt:
        log_info("Ctrl+C diterima; pemantauan dihentikan dengan aman")


if __name__ == "__main__":
    main()
