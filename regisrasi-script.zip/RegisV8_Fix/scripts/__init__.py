"""Standalone RegisV8 helper scripts."""
